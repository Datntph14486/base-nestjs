export enum MessageQueueExchange {
  userServiceQueue = 'user_service_queue',
}
