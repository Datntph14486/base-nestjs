export enum MessagePatternCmd {
  GetPermissionsByRole = 'GET_PERMISSIONS_BY_ROLE',
}
