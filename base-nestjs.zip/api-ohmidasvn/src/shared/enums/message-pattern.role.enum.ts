export enum MessagePatternRole {
  RoleService = 'ROLE_SERVICE',
}
